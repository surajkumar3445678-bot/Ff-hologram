कैरेक्टर टूल ऐप (Android): रंग बदलो + दीवार के आर-पार X-ray

ऐप में: GLB/GLTF/OBJ चुनो, रंग बदलो, X-ray चालू करो, और उसी फॉर्मेट में डाउनलोड करो (फ़ाइल "Downloads" फ़ोल्डर में जाती है)।
GLTF के साथ उसकी .bin और टेक्सचर फ़ाइलें भी एक साथ चुनो।

GitHub से APK बनाना:
1. GitHub पर नई repository बनाओ।
2. Add file > Upload files से यह पूरा ZIP बिना खोले अपलोड करो और Commit करो।
3. Add file > Create new file में नाम लिखो:  .github/workflows/build.yml
   और चैट में दिया workflow चिपकाकर Commit करो।
4. Actions टैब में "Build Android APK" चलेगा (5-8 मिनट)।
5. पूरा होने पर उस run के Artifacts से "Xray-App-APK" डाउनलोड करो, ZIP खोलो और APK इंस्टॉल करो।

इंटरनेट चालू रखो (Three.js इंटरनेट से आता है)।
पेज बदलना हो तो app/src/main/assets/index.html बदलो।
